import { InputHandler } from './core/InputHandler.js';
import { Camera } from './core/Camera.js';
import { SaveSystem } from './core/SaveSystem.js';
import { ApiClient } from './core/ApiClient.js';
import { TileMap } from './world/TileMap.js';
import { Player } from './entities/Player.js';
import { Enemy } from './entities/Enemy.js';
import { BattleSystem } from './systems/BattleSystem.js';

const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

const GAME_WIDTH = 640;
const GAME_HEIGHT = 360;
const MAP_SCALE = 2;
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;
ctx.imageSmoothingEnabled = false;

function resizeCanvas() {
  const scaleX = window.innerWidth / GAME_WIDTH;
  const scaleY = window.innerHeight / GAME_HEIGHT;
  const scale = Math.min(scaleX, scaleY);
  canvas.style.width = `${Math.floor(GAME_WIDTH * scale)}px`;
  canvas.style.height = `${Math.floor(GAME_HEIGHT * scale)}px`;
  canvas.style.imageRendering = 'pixelated';
  ctx.imageSmoothingEnabled = false;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Não achei a imagem em: ${src}`));
    img.src = src;
  });
}

function rectsOverlap(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function pointInRect(px, py, r) {
  return px >= r.x && px <= r.x + r.width && py >= r.y && py <= r.y + r.height;
}

const MAP_REGISTRY = {
  map01: { path: './data/map01.json', zona: 'FLORESTA_01', data: null },
  map02: { path: './data/map02.json', zona: 'FLORESTA_02', data: null },
  map03: { path: './data/map03.json', zona: 'FLORESTA_03', data: null },
  map04: { path: './data/map04.json', zona: 'FLORESTA_04', data: null },
  map05: { path: './data/map05.json', zona: 'FLORESTA_05', data: null },
  map06: { path: './data/map06.json', zona: 'FLORESTA_06', data: null },
  map07: { path: './data/map07.json', zona: 'FLORESTA_07', data: null },
};

async function getMapJson(mapKey) {
  const entry = MAP_REGISTRY[mapKey];
  if (!entry) return null;
  if (!entry.data) {
    const response = await fetch(entry.path);
    entry.data = await response.json();
  }
  return entry.data;
}

async function findDestinationPortal(portalName, originMapKey) {
  for (const mapKey of Object.keys(MAP_REGISTRY)) {
    if (mapKey === originMapKey) continue;

    const json = await getMapJson(mapKey);
    if (!json || !json.layers) continue;

    for (const layer of json.layers) {
      if (layer.type !== 'objectgroup') continue;
      const layerNameLower = (layer.name || '').trim().toLowerCase();
      const layerEhPortal = layerNameLower.startsWith('portal');

      if (!layerEhPortal && layerNameLower !== 'portais') continue;

      for (const obj of layer.objects) {
        if (!obj.width || !obj.height) continue;

        const nome = layerEhPortal
          ? layerNameLower
          : (obj.name || '').trim().toLowerCase();

        if (nome === portalName.toLowerCase()) {
          const propSaida = obj.properties?.find((p) => p.name === 'direcaoSaida');
          return {
            targetMapKey: mapKey,
            targetMapJson: json,
            portal: {
              x: obj.x,
              y: obj.y,
              width: obj.width,
              height: obj.height,
              direcaoSaida: propSaida ? propSaida.value : null,
            },
          };
        }
      }
    }
  }
  return null;
}

function getSafeSpawnPosition(portal, mapJson, player) {
  const mapWidthPx = mapJson.width * mapJson.tilewidth;
  const mapHeightPx = mapJson.height * mapJson.tileheight;
  const offset = 24;

  const hitbox = player.getHitboxAt(player.x, player.y);
  const offsetHitboxX = hitbox.x - player.x;
  const offsetHitboxY = hitbox.y - player.y;

  let targetHitboxX = portal.x + portal.width / 2 - hitbox.width / 2;
  let targetHitboxY = portal.y + portal.height / 2 - hitbox.height / 2;

  if (portal.direcaoSaida === 'baixo') {
    targetHitboxY = portal.y + portal.height + offset;
  } else if (portal.direcaoSaida === 'cima') {
    targetHitboxY = portal.y - hitbox.height - offset;
  } else if (portal.direcaoSaida === 'direita') {
    targetHitboxX = portal.x + portal.width + offset;
  } else if (portal.direcaoSaida === 'esquerda') {
    targetHitboxX = portal.x - hitbox.width - offset;
  } else {
    if (portal.x <= 32) {
      targetHitboxX = portal.x + portal.width + offset;
    } else if (portal.x + portal.width >= mapWidthPx - 32) {
      targetHitboxX = portal.x - hitbox.width - offset;
    } else if (portal.y <= 48) {
      targetHitboxY = portal.y + portal.height + offset;
    } else if (portal.y + portal.height >= mapHeightPx - 48) {
      targetHitboxY = portal.y - hitbox.height - offset;
    }
  }

  targetHitboxX = Math.max(4, Math.min(mapWidthPx - hitbox.width - 4, targetHitboxX));
  targetHitboxY = Math.max(4, Math.min(mapHeightPx - hitbox.height - 4, targetHitboxY));

  return {
    x: targetHitboxX - offsetHitboxX,
    y: targetHitboxY - offsetHitboxY,
  };
}

const MENU_BTN = { x: GAME_WIDTH - 36, y: 10, width: 26, height: 24 };
const MENU_DROPDOWN = { x: GAME_WIDTH - 144, y: 38, width: 134, height: 128 };
const MENU_ITEMS = [
  { id: 'INVENTARIO', label: 'Inventário', keyHint: '[I]', yOffset: 6 },
  { id: 'BAU', label: 'Abrir Baú', keyHint: '[E]', yOffset: 30 },
  { id: 'HUB', label: 'Santuário', keyHint: '[H]', yOffset: 54 },
  { id: 'SALVAR', label: 'Salvar', keyHint: '[G]', yOffset: 78 },
  { id: 'PAUSAR', label: 'Pausar', keyHint: '[P]', yOffset: 102 },
];

function drawRpgBar(ctx, x, y, w, h, ratio, bgColor, fillColor, highlightColor, text) {
  ctx.fillStyle = '#0b0c10';
  ctx.fillRect(x - 1, y - 1, w + 2, h + 2);

  ctx.fillStyle = bgColor;
  ctx.fillRect(x, y, w, h);

  const fillW = Math.max(0, Math.min(w, Math.round(w * ratio)));
  if (fillW > 0) {
    ctx.fillStyle = fillColor;
    ctx.fillRect(x, y, fillW, h);

    ctx.fillStyle = highlightColor;
    ctx.fillRect(x, y, fillW, Math.max(2, Math.floor(h * 0.3)));
  }

  if (text) {
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#090a0f';
    ctx.fillText(text, x + Math.floor(w / 2) + 1, y + h - 2);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(text, x + Math.floor(w / 2), y + h - 3);
    ctx.textAlign = 'left';
  }
}

function renderHUD(ctx, player, apiClient, feedbackMsg, feedbackTimer, menuOpen, hoveredMenuId) {
  const maxVida = player.stats.getInt('VIDA_MAXIMA');
  const maxEnergia = player.stats.getInt('ENERGIA_MAXIMA');
  const hpRatio = Math.max(0, Math.min(1, player.vida / maxVida));
  const mpRatio = Math.max(0, Math.min(1, player.energia / maxEnergia));
  const xpRatio = player.progressao.progressoDoNivel();

  ctx.fillStyle = 'rgba(14, 16, 24, 0.88)';
  ctx.fillRect(10, 10, 198, 56);
  ctx.strokeStyle = '#c9a227';
  ctx.lineWidth = 1;
  ctx.strokeRect(10.5, 10.5, 197, 55);
  ctx.strokeStyle = '#3b331e';
  ctx.strokeRect(12.5, 12.5, 193, 51);

  ctx.fillStyle = '#1d2233';
  ctx.fillRect(16, 16, 36, 44);
  ctx.strokeStyle = '#e0b841';
  ctx.strokeRect(16.5, 16.5, 35, 43);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#e0b841';
  ctx.font = 'bold 8px monospace';
  ctx.fillText('NÍVEL', 34, 27);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px monospace';
  ctx.fillText(`${player.progressao.nivel}`, 34, 44);

  ctx.fillStyle = '#241f11';
  ctx.fillRect(19, 50, 30, 5);
  ctx.fillStyle = '#f4d35e';
  ctx.fillRect(19, 50, Math.round(30 * xpRatio), 5);
  ctx.textAlign = 'left';

  ctx.font = 'bold 9px monospace';
  ctx.fillStyle = '#ff6b6b';
  ctx.fillText('HP', 58, 25);
  drawRpgBar(
    ctx,
    74,
    16,
    126,
    11,
    hpRatio,
    '#3b1219',
    '#d62828',
    '#ff758f',
    `${player.vida}/${maxVida}`
  );

  ctx.fillStyle = '#4cc9f0';
  ctx.fillText('MP', 58, 40);
  drawRpgBar(
    ctx,
    74,
    31,
    126,
    11,
    mpRatio,
    '#102542',
    '#219ebc',
    '#8ecae6',
    `${Math.round(player.energia)}/${maxEnergia}`
  );

  ctx.font = 'bold 9px monospace';
  ctx.fillStyle = '#f4d35e';
  ctx.fillText(`XP ${Math.round(xpRatio * 100)}%`, 58, 56);

  ctx.fillStyle = '#c77dff';
  ctx.fillText(`◆${player.fragmentosColetados}`, 114, 56);
  ctx.fillStyle = '#4ecdc4';
  ctx.fillText(`✦${player.fragmentosPurificados}`, 158, 56);

  ctx.font = 'bold 9px monospace';
  ctx.textAlign = 'right';
  ctx.fillStyle = apiClient.conectado ? '#2ecc71' : '#f39c12';
  ctx.fillText(apiClient.conectado ? 'ONLINE' : 'OFFLINE', MENU_BTN.x - 6, 25);
  ctx.textAlign = 'left';

  ctx.fillStyle = menuOpen ? 'rgba(38, 42, 62, 0.95)' : 'rgba(14, 16, 24, 0.88)';
  ctx.fillRect(MENU_BTN.x, MENU_BTN.y, MENU_BTN.width, MENU_BTN.height);
  ctx.strokeStyle = menuOpen ? '#ffe66d' : '#c9a227';
  ctx.strokeRect(MENU_BTN.x + 0.5, MENU_BTN.y + 0.5, MENU_BTN.width - 1, MENU_BTN.height - 1);

  ctx.fillStyle = '#ffffff';
  const barX = MENU_BTN.x + 6;
  const barW = MENU_BTN.width - 12;
  ctx.fillRect(barX, MENU_BTN.y + 6, barW, 2);
  ctx.fillRect(barX, MENU_BTN.y + 11, barW, 2);
  ctx.fillRect(barX, MENU_BTN.y + 16, barW, 2);

  if (menuOpen) {
    ctx.fillStyle = 'rgba(14, 16, 24, 0.95)';
    ctx.fillRect(MENU_DROPDOWN.x, MENU_DROPDOWN.y, MENU_DROPDOWN.width, MENU_DROPDOWN.height);
    ctx.strokeStyle = '#c9a227';
    ctx.strokeRect(
      MENU_DROPDOWN.x + 0.5,
      MENU_DROPDOWN.y + 0.5,
      MENU_DROPDOWN.width - 1,
      MENU_DROPDOWN.height - 1
    );

    for (const item of MENU_ITEMS) {
      const itemRect = {
        x: MENU_DROPDOWN.x + 4,
        y: MENU_DROPDOWN.y + item.yOffset,
        width: MENU_DROPDOWN.width - 8,
        height: 20,
      };

      if (hoveredMenuId === item.id) {
        ctx.fillStyle = 'rgba(201, 162, 39, 0.25)';
        ctx.fillRect(itemRect.x, itemRect.y, itemRect.width, itemRect.height);
      }

      ctx.font = 'bold 10px monospace';
      ctx.fillStyle = hoveredMenuId === item.id ? '#ffe66d' : '#ffffff';
      ctx.fillText(item.label, itemRect.x + 6, itemRect.y + 14);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#9aa5b1';
      ctx.fillText(item.keyHint, itemRect.x + itemRect.width - 6, itemRect.y + 14);
      ctx.textAlign = 'left';
    }
  }

  if (feedbackTimer > 0 && feedbackMsg) {
    ctx.fillStyle = 'rgba(14, 16, 24, 0.92)';
    ctx.fillRect(12, canvas.height - 32, canvas.width - 24, 22);
    ctx.strokeStyle = '#4ecdc4';
    ctx.strokeRect(12.5, canvas.height - 31.5, canvas.width - 25, 21);
    ctx.fillStyle = '#4ecdc4';
    ctx.font = 'bold 11px monospace';
    ctx.fillText(feedbackMsg, 20, canvas.height - 17);
  }
}

function renderOverlayScreen(ctx, title, subtitle, extraLine = '') {
  ctx.fillStyle = 'rgba(10, 10, 16, 0.88)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffe66d';
  ctx.font = 'bold 26px monospace';
  ctx.fillText(title, canvas.width / 2, 132);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 14px monospace';
  ctx.fillText(subtitle, canvas.width / 2, 182);

  if (extraLine) {
    ctx.fillStyle = '#4ecdc4';
    ctx.fillText(extraLine, canvas.width / 2, 214);
  }
  ctx.textAlign = 'left';
}

function renderInventoryScreen(ctx, player) {
  ctx.fillStyle = 'rgba(10, 10, 16, 0.90)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const boxX = 140;
  const boxY = 55;
  const boxW = 360;
  const boxH = 240;

  ctx.fillStyle = '#141724';
  ctx.fillRect(boxX, boxY, boxW, boxH);
  ctx.strokeStyle = '#c9a227';
  ctx.lineWidth = 2;
  ctx.strokeRect(boxX, boxY, boxW, boxH);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffe66d';
  ctx.font = 'bold 18px monospace';
  ctx.fillText('INVENTÁRIO', canvas.width / 2, boxY + 28);

  ctx.textAlign = 'left';
  const itens = player.inventario || [];

  if (itens.length === 0) {
    ctx.fillStyle = '#9aa5b1';
    ctx.font = 'bold 12px monospace';
    ctx.fillText('Mochila vazia.', boxX + 24, boxY + 70);
  } else {
    itens.forEach((item, index) => {
      const itemY = boxY + 62 + index * 32;
      ctx.fillStyle = '#1f2438';
      ctx.fillRect(boxX + 18, itemY - 14, boxW - 36, 24);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(`${item.nome} (x${item.qtd})`, boxX + 26, itemY + 2);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#4ecdc4';
      ctx.font = '11px monospace';
      ctx.fillText(item.desc, boxX + boxW - 26, itemY + 2);
      ctx.textAlign = 'left';
    });
  }

  ctx.textAlign = 'center';
  ctx.fillStyle = '#e0b841';
  ctx.font = 'bold 11px monospace';
  ctx.fillText('[I] ou [ESC] Fechar Inventário', canvas.width / 2, boxY + boxH - 16);
  ctx.textAlign = 'left';
}

function afastarInimigoAposFuga(enemy, player, tileMap) {
  if (!enemy || !player) return;
  enemy.fleeCooldownTimer = 1.8;

  let dx = enemy.x - player.x;
  let dy = enemy.y - player.y;
  const dist = Math.hypot(dx, dy);

  if (dist < 0.001) {
    dx = 1;
    dy = 0;
  } else {
    dx /= dist;
    dy /= dist;
  }

  for (const passo of [28, 20, 14]) {
    const nx = enemy.x + dx * passo;
    const ny = enemy.y + dy * passo;
    if (!tileMap || typeof tileMap.checkCollision !== 'function') {
      enemy.x = nx;
      enemy.y = ny;
      break;
    }
    const hb = enemy.getHitboxAt(nx, ny);
    if (!tileMap.checkCollision(hb)) {
      enemy.x = nx;
      enemy.y = ny;
      break;
    }
  }
}

async function init() {
  try {
    const [
      initialMapData,
      tilesetImage,
      playerSprite,
      battleBgImage,
      b1, b2, b3, b4, b5, b6,
      c1, c2, c3, c4, c5, c6,
    ] = await Promise.all([
      getMapJson('map01'),
      loadImage('./assets/tileset.png'),
      loadImage('./assets/heroi_padrao.png'),
      loadImage('./assets/spr_battle_empty.png'),
      loadImage('./assets/baixo1.png'),
      loadImage('./assets/baixo2.png'),
      loadImage('./assets/baixo3.png'),
      loadImage('./assets/baixo4.png'),
      loadImage('./assets/baixo5.png'),
      loadImage('./assets/baixo6.png'),
      loadImage('./assets/cima1.png'),
      loadImage('./assets/cima2.png'),
      loadImage('./assets/cima3.png'),
      loadImage('./assets/cima4.png'),
      loadImage('./assets/cima5.png'),
      loadImage('./assets/cima6.png'),
    ]);
    const downFrames = [b1, b2, b3, b4, b5, b6];
    const upFrames = [c1, c2, c3, c4, c5, c6];

    const input = new InputHandler();
    const saveSystem = new SaveSystem();
    const apiClient = new ApiClient();
    const battleSystem = new BattleSystem(apiClient);
    battleSystem.backgroundImage = battleBgImage;

    let currentMapKey = 'map01';
    let isTransitioningMap = false;
    let tileMap = new TileMap(initialMapData, tilesetImage);
    let camera = new Camera(
      canvas.width / MAP_SCALE,
      canvas.height / MAP_SCALE,
      tileMap.pixelWidth,
      tileMap.pixelHeight
    );

    const SPAWN_X = 300;
    const SPAWN_Y = 200;

    const player = new Player(SPAWN_X, SPAWN_Y, 'Arthur', playerSprite, {
      down: downFrames,
      up: upFrames,
    });
    player.fragmentosColetados = 0;
    player.fragmentosPurificados = 0;
    player.inventario = [
      { nome: 'Poção de Vida', qtd: 2, desc: 'Restaura 30 de HP' },
      { nome: 'Poção de Energia', qtd: 1, desc: 'Restaura 20 de MP' },
    ];

    battleSystem.backgroundImage = battleBgImage;
    let enemies = [];

    let gameState = 'TITLE';
    let feedbackMsg = '';
    let feedbackTimer = 0;
    let moveSyncTimer = 0;

    let menuOpen = false;
    let hoveredMenuId = null;

    function avisar(texto, duracao = 2.5) {
      feedbackMsg = texto;
      feedbackTimer = duracao;
    }

    function executarAcaoMenu(acaoId) {
      menuOpen = false;
      hoveredMenuId = null;

      if (acaoId === 'INVENTARIO') {
        gameState = 'INVENTORY';
      } else if (acaoId === 'SALVAR') {
        saveSystem.save(player);
        if (apiClient.conectado) {
          apiClient.salvar(1).then((r) => avisar(r ? r.mensagem : 'Jogo salvo!'));
        } else {
          avisar('Jogo salvo localmente!');
        }
      } else if (acaoId === 'HUB') {
        if (apiClient.conectado) {
          apiClient.entrarNoHub().then((r) => {
            if (r && r.ok) {
              gameState = 'HUB';
              avisar(r.mensagem);
            }
          });
        } else {
          gameState = 'HUB';
        }
      } else if (acaoId === 'BAU') {
        if (apiClient.conectado) {
          apiClient.agir('ABRIR_BAU').then((r) => {
            if (r && r.estado === 'BATALHA' && r.inimigo) {
              const guardiao = new Enemy(player.x, player.y, r.inimigo.nome, r.inimigo.nivel);
              battleSystem.startBattle(player, guardiao, r);
              gameState = 'BATTLE';
            } else if (r) {
              avisar(r.mensagem);
            }
          });
        } else {
          avisar('Nenhum baú próximo no modo offline.');
        }
      } else if (acaoId === 'PAUSAR') {
        gameState = 'PAUSED';
      }
    }

    function getCanvasMousePos(event) {
      const rect = canvas.getBoundingClientRect();
      return {
        x: ((event.clientX - rect.left) / rect.width) * GAME_WIDTH,
        y: ((event.clientY - rect.top) / rect.height) * GAME_HEIGHT,
      };
    }

    canvas.addEventListener('mousemove', (e) => {
      if (gameState !== 'PLAYING' || !menuOpen) {
        hoveredMenuId = null;
        return;
      }
      const pos = getCanvasMousePos(e);
      hoveredMenuId = null;
      for (const item of MENU_ITEMS) {
        const itemRect = {
          x: MENU_DROPDOWN.x + 4,
          y: MENU_DROPDOWN.y + item.yOffset,
          width: MENU_DROPDOWN.width - 8,
          height: 20,
        };
        if (pointInRect(pos.x, pos.y, itemRect)) {
          hoveredMenuId = item.id;
          break;
        }
      }
    });

    canvas.addEventListener('click', (e) => {
      if (gameState !== 'PLAYING') return;
      const pos = getCanvasMousePos(e);

      if (pointInRect(pos.x, pos.y, MENU_BTN)) {
        menuOpen = !menuOpen;
        return;
      }

      if (menuOpen) {
        for (const item of MENU_ITEMS) {
          const itemRect = {
            x: MENU_DROPDOWN.x + 4,
            y: MENU_DROPDOWN.y + item.yOffset,
            width: MENU_DROPDOWN.width - 8,
            height: 20,
          };
          if (pointInRect(pos.x, pos.y, itemRect)) {
            executarAcaoMenu(item.id);
            return;
          }
        }
        menuOpen = false;
      }
    });

    function sortearSpawnNaArea(areas, tipoKey, nivel = 1) {
      if (!areas || !areas.length) return null;

      const tempEnemy = new Enemy(0, 0, 'temp', nivel, tipoKey);
      const hbOffsetX = tempEnemy.hitbox.offsetX;
      const hbOffsetY = tempEnemy.hitbox.offsetY;
      const hbW = tempEnemy.hitbox.width;
      const hbH = tempEnemy.hitbox.height;

      for (let tentativa = 0; tentativa < 40; tentativa++) {
        const area = areas[Math.floor(Math.random() * areas.length)];
        let hbX;
        let hbY;

        if (area.tipo === 'rect') {
          hbX = area.x + Math.random() * Math.max(1, area.width - hbW);
          hbY = area.y + Math.random() * Math.max(1, area.height - hbH);
        } else {
          hbX = area.minX + Math.random() * Math.max(1, area.maxX - area.minX - hbW);
          hbY = area.minY + Math.random() * Math.max(1, area.maxY - area.minY - hbH);
        }

        const worldX = hbX - hbOffsetX;
        const worldY = hbY - hbOffsetY;
        const hitboxFinal = tempEnemy.getHitboxAt(worldX, worldY);

        if (
          !tileMap.checkCollision(hitboxFinal) &&
          tileMap.isInsideEnemyArea(hitboxFinal, tipoKey)
        ) {
          return { x: worldX, y: worldY };
        }
      }

      return null;
    }

    function spawnEnemiesForCurrentMap() {
      const tiposNoMapa = [
        { tipoKey: 'morto_vivo', nome: 'Morto-Vivo', qtd: 3, nivel: 1 },
        { tipoKey: 'hospedeiro_cristalino', nome: 'Hospedeiro Cristalino', qtd: 2, nivel: 2 },
        { tipoKey: 'monge_corrompido', nome: 'Monge Corrompido', qtd: 2, nivel: 3 },
        { tipoKey: 'boss_golem_de_pedra', nome: 'Boss Golem de Pedra', qtd: 1, nivel: 5 },
        { tipoKey: 'sentinela_gelo', nome: 'Sentinela de Gelo', qtd: 2, nivel: 2 },
        { tipoKey: 'esqueleto_congelado', nome: 'Esqueleto Congelado', qtd: 2, nivel: 2 },
        { tipoKey: 'lobo_geada', nome: 'Lobo da Geada', qtd: 2, nivel: 3 },
      ];

      const spawned = [];

      for (const cfg of tiposNoMapa) {
        const areas = tileMap.getEnemyAreas(cfg.tipoKey);
        if (!areas.length) continue;

        for (let i = 0; i < cfg.qtd; i++) {
          const pos = sortearSpawnNaArea(areas, cfg.tipoKey, cfg.nivel);
          if (pos) {
            spawned.push(new Enemy(pos.x, pos.y, cfg.nome, cfg.nivel, cfg.tipoKey));
          }
        }
      }

      if (spawned.length > 0) {
        enemies = spawned;
      } else if (tileMap.enemySpawns && tileMap.enemySpawns.length > 0) {
        enemies = tileMap.enemySpawns.map((s) => new Enemy(s.x, s.y, s.name, 1, 'corrompido'));
      } else if (currentMapKey === 'map01') {
        enemies = [
          new Enemy(240, 220, 'Slime Verde', 1, 'corrompido'),
          new Enemy(350, 240, 'Morcego Sombrio', 2, 'corrompido'),
          new Enemy(310, 320, 'Corrompido', 2, 'corrompido'),
        ];
      } else {
        enemies = [];
      }
    }

    async function checkAndUsePortals() {
      if (isTransitioningMap || !tileMap.portals || tileMap.portals.length === 0) return;

      const playerRect = player.getHitboxAt(player.x, player.y);

      for (const portal of tileMap.portals) {
        if (rectsOverlap(playerRect, portal)) {
          isTransitioningMap = true;

          const dest = await findDestinationPortal(portal.nome, currentMapKey);
          if (dest) {
            currentMapKey = dest.targetMapKey;
            tileMap = new TileMap(dest.targetMapJson, tilesetImage);
            camera = new Camera(
              canvas.width / MAP_SCALE,
              canvas.height / MAP_SCALE,
              tileMap.pixelWidth,
              tileMap.pixelHeight
            );

            const spawn = getSafeSpawnPosition(dest.portal, dest.targetMapJson, player);
            player.x = spawn.x;
            player.y = spawn.y;

            spawnEnemiesForCurrentMap();
            camera.follow(player);
            avisar(`Entrou em ${currentMapKey.toUpperCase()} (${portal.nome})`, 1.5);
          } else {
            avisar(`Portal "${portal.nome}" sem destino conectado.`, 1.5);
          }

          setTimeout(() => {
            isTransitioningMap = false;
          }, 400);
          break;
        }
      }
    }

    apiClient.onEstadoAtualizado = (resp) => {
      if (!resp || !resp.heroi) return;
      const h = resp.heroi;
      player.nome = h.nome || player.nome;
      player.vida = h.vida;
      player.stats.setBase('VIDA_MAXIMA', h.vidaMaxima);
      if (player.progressao) player.progressao.nivel = h.nivel;
      player.fragmentosColetados = h.fragmentosColetados ?? player.fragmentosColetados;
      player.fragmentosPurificados = h.fragmentosPurificados ?? player.fragmentosPurificados;
    };

    async function setupWorld(loadFromSave = false) {
      currentMapKey = 'map01';
      menuOpen = false;
      const map01Data = await getMapJson('map01');
      tileMap = new TileMap(map01Data, tilesetImage);
      camera = new Camera(
        canvas.width / MAP_SCALE,
        canvas.height / MAP_SCALE,
        tileMap.pixelWidth,
        tileMap.pixelHeight
      );

      player.reset(SPAWN_X, SPAWN_Y);
      player.fragmentosColetados = 0;
      player.fragmentosPurificados = 0;
      player.inventario = [
        { nome: 'Poção de Vida', qtd: 2, desc: 'Restaura 30 de HP' },
        { nome: 'Poção de Energia', qtd: 1, desc: 'Restaura 20 de MP' },
      ];

      const online = await apiClient.conectar();

      if (online) {
        if (loadFromSave) {
          const r = await apiClient.carregar(1);
          if (r && r.ok && r.heroi) {
            player.x = r.heroi.x || SPAWN_X;
            player.y = r.heroi.y || SPAWN_Y;
            avisar(r.mensagem);
          } else {
            await apiClient.novoJogo(player.nome, 'Guerreiro', player.stats.getInt('VIDA_MAXIMA'));
          }
        } else {
          const r = await apiClient.novoJogo(player.nome, 'Guerreiro', player.stats.getInt('VIDA_MAXIMA'));
          if (r) avisar(r.mensagem);
        }
      } else if (loadFromSave && saveSystem.hasSave()) {
        const saved = saveSystem.load();
        player.applySaveData(saved);
        avisar('Save local carregado (Offline).');
      }

      spawnEnemiesForCurrentMap();
      camera.follow(player);
    }

    let lastTime = performance.now();

    function gameLoop(timestamp) {
      const deltaTime = Math.min((timestamp - lastTime) / 1000, 0.05);
      lastTime = timestamp;

      if (feedbackTimer > 0) {
        feedbackTimer = Math.max(0, feedbackTimer - deltaTime);
      }

      if (gameState === 'TITLE') {
        if (input.consumeKey('enter')) {
          setupWorld(false).then(() => { gameState = 'PLAYING'; });
        } else if (input.consumeKey('c')) {
          setupWorld(true).then(() => { gameState = 'PLAYING'; });
        }
      } else if (gameState === 'PLAYING') {
        if (input.consumeKey('m')) {
          menuOpen = !menuOpen;
        }

        if (input.consumeKey('escape')) {
          if (menuOpen) {
            menuOpen = false;
          } else {
            executarAcaoMenu('PAUSAR');
          }
        }

        if (input.consumeKey('i')) executarAcaoMenu('INVENTARIO');
        if (input.consumeKey('p')) executarAcaoMenu('PAUSAR');
        if (input.consumeKey('g')) executarAcaoMenu('SALVAR');
        if (input.consumeKey('h')) executarAcaoMenu('HUB');
        if (input.consumeKey('e')) executarAcaoMenu('BAU');

        player.update(deltaTime, input, tileMap);
        checkAndUsePortals();

        const zonaAtual = MAP_REGISTRY[currentMapKey]?.zona || 'FLORESTA_01';

        moveSyncTimer += deltaTime;
        if (apiClient.conectado && moveSyncTimer >= 0.25) {
          moveSyncTimer = 0;
          apiClient.mover(player.x, player.y, zonaAtual).then((r) => {
            if (r && r.estado === 'BATALHA' && r.inimigo && gameState === 'PLAYING') {
              const encInimigo = new Enemy(player.x, player.y, r.inimigo.nome, r.inimigo.nivel);
              battleSystem.startBattle(player, encInimigo, r);
              menuOpen = false;
              gameState = 'BATTLE';
            }
          });
        }

        const playerRect = player.getHitboxAt(player.x, player.y);
        for (const enemy of enemies) {
          if (enemy.state === 'DEAD') continue;

          if (enemy.fleeCooldownTimer > 0) {
            enemy.fleeCooldownTimer = Math.max(0, enemy.fleeCooldownTimer - deltaTime);
            enemy.update(deltaTime, player, tileMap);
            continue;
          }

          enemy.update(deltaTime, player, tileMap);

          const enemyRect = enemy.getHitboxAt(enemy.x, enemy.y);
          if (rectsOverlap(playerRect, enemyRect)) {
            menuOpen = false;
            if (apiClient.conectado) {
              apiClient.mover(player.x + 20, player.y, zonaAtual).then((r) => {
                battleSystem.startBattle(player, enemy, r && r.estado === 'BATALHA' ? r : null);
                gameState = 'BATTLE';
              });
            } else {
              battleSystem.startBattle(player, enemy, null);
              gameState = 'BATTLE';
            }
            break;
          }
        }

        camera.follow(player);
      } else if (gameState === 'HUB') {
        if (input.consumeKey('enter') || input.consumeKey('j')) {
          if (apiClient.conectado) {
            apiClient.purificarFragmentos().then((r) => {
              if (r) avisar(r.mensagem);
            });
          } else if (player.fragmentosColetados > 0) {
            const qtd = player.fragmentosColetados;
            player.fragmentosPurificados += qtd;
            player.fragmentosColetados = 0;
            avisar(`${qtd} fragmento(s) purificado(s)!`);
          } else {
            avisar('Não há fragmentos para purificar.');
          }
        }
        if (input.consumeKey('escape') || input.consumeKey('h')) {
          if (apiClient.conectado) {
            apiClient.sairDoHub().then(() => { gameState = 'PLAYING'; });
          } else {
            gameState = 'PLAYING';
          }
        }
      } else if (gameState === 'BATTLE') {
        const resultado = battleSystem.update(deltaTime, player, input);
        if (resultado === 'VITORIA') {
          gameState = 'PLAYING';
        } else if (resultado === 'FUGA') {
          afastarInimigoAposFuga(battleSystem.enemy, player, tileMap);
          moveSyncTimer = 0;
          gameState = 'PLAYING';
        } else if (resultado === 'DERROTA') {
          gameState = 'GAME_OVER';
        }
      } else if (gameState === 'PAUSED') {
        if (input.consumeKey('escape') || input.consumeKey('p')) {
          gameState = 'PLAYING';
        } else if (input.consumeKey('g')) {
          saveSystem.save(player);
          if (apiClient.conectado) apiClient.salvar(1);
          avisar('Progresso salvo no Slot 1!');
        }
      } else if (gameState === 'INVENTORY') {
        if (input.consumeKey('escape') || input.consumeKey('i')) {
          gameState = 'PLAYING';
        }
      } else if (gameState === 'GAME_OVER') {
        if (input.consumeKey('r')) {
          if (apiClient.conectado) {
            apiClient.voltarAoMenu().then(() => {
              setupWorld(true).then(() => { gameState = 'PLAYING'; });
            });
          } else {
            setupWorld(saveSystem.hasSave()).then(() => { gameState = 'PLAYING'; });
          }
        }
      }

      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (gameState === 'TITLE') {
        renderOverlayScreen(
          ctx,
          'MARK OF BALANCE',
          'Pressione [ENTER] para Novo Jogo',
          'Pressione [C] para Carregar Slot 1'
        );
      } else if (gameState === 'BATTLE') {
        battleSystem.render(ctx, canvas, player);
      } else if (gameState === 'HUB') {
        renderOverlayScreen(
          ctx,
          'SANTUÁRIO (HUB)',
          `Coletados: ${player.fragmentosColetados}   |   Purificados: ${player.fragmentosPurificados}`,
          '[ENTER] Purificar Fragmentos   |   [H] ou [ESC] Voltar ao Mapa'
        );
      } else if (gameState === 'INVENTORY') {
        renderInventoryScreen(ctx, player);
      } else {
        ctx.save();
        ctx.scale(MAP_SCALE, MAP_SCALE);
        tileMap.renderAllLayers(ctx, camera);
        for (const enemy of enemies) {
          enemy.render(ctx, camera);
        }
        player.render(ctx, camera);
        ctx.restore();

        renderHUD(ctx, player, apiClient, feedbackMsg, feedbackTimer, menuOpen, hoveredMenuId);

        if (gameState === 'PAUSED') {
          renderOverlayScreen(
            ctx,
            'JOGO PAUSADO',
            '[P] ou [ESC] Continuar   |   [G] Salvar Slot 1',
            feedbackTimer > 0 ? feedbackMsg : ''
          );
        } else if (gameState === 'GAME_OVER') {
          renderOverlayScreen(
            ctx,
            'VOCÊ CAIU EM COMBATE',
            'Pressione [R] para Carregar Último Save'
          );
        }
      }

      requestAnimationFrame(gameLoop);
    }

    requestAnimationFrame(gameLoop);
  } catch (erro) {
    console.error('Erro ao iniciar o jogo:', erro.message);
  }
}

init();
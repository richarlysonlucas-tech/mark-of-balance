export class TileMap {
  constructor(mapData, tilesetImage) {
    this.mapData = mapData;
    this.tilesetImage = tilesetImage;

    this.tileSize = mapData.tilewidth; // 16
    this.cols = mapData.width;
    this.rows = mapData.height;

    this.pixelWidth = this.cols * this.tileSize;
    this.pixelHeight = this.rows * this.tileSize;
    this.tilesetCols = Math.floor(tilesetImage.width / this.tileSize);

    this.tileLayers = [];
    this.collisionBoxes = [];
    this.portals = [];
    this.enemySpawns = [];
    this.enemyAreasByType = {};

    for (const layer of mapData.layers) {
      if (layer.type === 'tilelayer' && layer.visible) {
        this.tileLayers.push(layer);
      } else if (layer.type === 'objectgroup') {
        const layerName = (layer.name || '').trim();
        const layerNameLower = layerName.toLowerCase();
        const ox = layer.offsetx || 0;
        const oy = layer.offsety || 0;

        if (layerNameLower === 'colisoes') {
          for (const obj of layer.objects || []) {
            if ((obj.width || 0) > 0 && (obj.height || 0) > 0) {
              this.collisionBoxes.push({
                x: (obj.x || 0) + ox,
                y: (obj.y || 0) + oy,
                width: obj.width,
                height: obj.height,
              });
            }
          }
        } else if (layerNameLower.startsWith('portal') || layerNameLower === 'portais') {
          for (const obj of layer.objects || []) {
            const portalName = layerNameLower.startsWith('portal')
              ? layerNameLower
              : (obj.name || '').trim().toLowerCase();

            if (portalName.startsWith('portal')) {
              const propSaida = obj.properties?.find((p) => p.name === 'direcaoSaida');
              this.portals.push({
                nome: portalName,
                x: (obj.x || 0) + ox,
                y: (obj.y || 0) + oy,
                width: obj.width || 16,
                height: obj.height || 16,
                direcaoSaida: propSaida ? propSaida.value : null,
              });
            }
          }
        } else if (layerNameLower === 'inimigos' || layerNameLower === 'spawns') {
          for (const obj of layer.objects || []) {
            this.enemySpawns.push({
              x: (obj.x || 0) + ox,
              y: (obj.y || 0) + oy,
              name: obj.name || 'Inimigo',
            });
          }
        } else if (
          layerNameLower.includes('inimigo') ||
          layerNameLower.includes('hospedeiro') ||
          layerNameLower.includes('monge') ||
          layerNameLower.includes('golem') ||
          layerNameLower.includes('boss')
        ) {
          const tipoKey = TileMap.normalizarTipoInimigo(layerNameLower);
          if (!this.enemyAreasByType[tipoKey]) {
            this.enemyAreasByType[tipoKey] = [];
          }

          for (const obj of layer.objects || []) {
            const area = TileMap.criarAreaDeObjeto(obj, ox, oy, layerName);
            if (area) {
              this.enemyAreasByType[tipoKey].push(area);
            }
          }
        }
      }
    }
  }

  static normalizarTipoInimigo(nomeCamada) {
    const clean = (nomeCamada || '').toLowerCase().trim();
    if (clean.includes('morto vivo') || clean.includes('mortos vivos')) return 'morto_vivo';
    if (clean.includes('hospedeiro')) return 'hospedeiro_cristalino';
    if (clean.includes('monge')) return 'monge_corrompido';
    if (clean.includes('golem') || clean.includes('boss')) return 'boss_golem_de_pedra';
    if (clean.includes('sentinela')) return 'sentinela_gelo';
    if (clean.includes('esqueleto')) return 'esqueleto_congelado';
    if (clean.includes('lobo')) return 'lobo_geada';
    return clean.replace(/\s+/g, '_');
  }

  static criarAreaDeObjeto(obj, ox, oy, layerName) {
    const baseX = (obj.x || 0) + ox;
    const baseY = (obj.y || 0) + oy;

    if (Array.isArray(obj.polygon) && obj.polygon.length >= 3) {
      const pontos = obj.polygon.map((p) => ({
        x: baseX + p.x,
        y: baseY + p.y,
      }));
      const xs = pontos.map((p) => p.x);
      const ys = pontos.map((p) => p.y);
      return {
        tipo: 'polygon',
        layerName,
        pontos,
        minX: Math.min(...xs),
        maxX: Math.max(...xs),
        minY: Math.min(...ys),
        maxY: Math.max(...ys),
      };
    }

    if ((obj.width || 0) > 0 && (obj.height || 0) > 0) {
      return {
        tipo: 'rect',
        layerName,
        x: baseX,
        y: baseY,
        width: obj.width,
        height: obj.height,
      };
    }

    return null;
  }

  static pontoEmPoligono(px, py, pontos) {
    let dentro = false;
    for (let i = 0, j = pontos.length - 1; i < pontos.length; j = i++) {
      const xi = pontos[i].x;
      const yi = pontos[i].y;
      const xj = pontos[j].x;
      const yj = pontos[j].y;

      const cruza =
        yi > py !== yj > py &&
        px < ((xj - xi) * (py - yi)) / (yj - yi + 1e-9) + xi;
      if (cruza) dentro = !dentro;
    }
    return dentro;
  }

  getEnemyAreas(tipoKey) {
    return this.enemyAreasByType[tipoKey] || [];
  }

  isInsideEnemyArea(rect, tipoKey) {
    const areas = this.getEnemyAreas(tipoKey);
    if (!areas.length) return true;

    const cantos = [
      { x: rect.x, y: rect.y },
      { x: rect.x + rect.width, y: rect.y },
      { x: rect.x, y: rect.y + rect.height },
      { x: rect.x + rect.width, y: rect.y + rect.height },
    ];

    return areas.some((area) => {
      if (area.tipo === 'rect') {
        return (
          rect.x >= area.x &&
          rect.x + rect.width <= area.x + area.width &&
          rect.y >= area.y &&
          rect.y + rect.height <= area.y + area.height
        );
      }
      return cantos.every((c) => TileMap.pontoEmPoligono(c.x, c.y, area.pontos));
    });
  }

  checkCollision(rect) {
    if (
      rect.x < 0 ||
      rect.y < 0 ||
      rect.x + rect.width > this.pixelWidth ||
      rect.y + rect.height > this.pixelHeight
    ) {
      return true;
    }

    for (const box of this.collisionBoxes) {
      const overlapped =
        rect.x < box.x + box.width &&
        rect.x + rect.width > box.x &&
        rect.y < box.y + box.height &&
        rect.y + rect.height > box.y;

      if (overlapped) {
        return true;
      }
    }

    return false;
  }

  renderAllLayers(ctx, camera) {
    const camX = Math.round(camera.x);
    const camY = Math.round(camera.y);

    const startCol = Math.max(0, Math.floor(camX / this.tileSize));
    const endCol = Math.min(this.cols - 1, Math.ceil((camX + camera.viewportWidth) / this.tileSize));
    const startRow = Math.max(0, Math.floor(camY / this.tileSize));
    const endRow = Math.min(this.rows - 1, Math.ceil((camY + camera.viewportHeight) / this.tileSize));

    const FLIP_HORIZONTAL = 0x80000000;
    const FLIP_VERTICAL = 0x40000000;

    for (const layer of this.tileLayers) {
      const data = layer.data;

      for (let row = startRow; row <= endRow; row++) {
        for (let col = startCol; col <= endCol; col++) {
          const rawGid = data[row * this.cols + col];
          if (rawGid === 0) continue;

          const flipH = (rawGid & FLIP_HORIZONTAL) !== 0;
          const flipV = (rawGid & FLIP_VERTICAL) !== 0;

          let cleanGid = rawGid & 0x1fffffff;
          if (cleanGid >= 11001) {
            cleanGid -= 11000;
          }
          const tileId = cleanGid - 1;

          const sx = (tileId % this.tilesetCols) * this.tileSize;
          const sy = Math.floor(tileId / this.tilesetCols) * this.tileSize;
          const dx = col * this.tileSize - camX;
          const dy = row * this.tileSize - camY;

          if (flipH || flipV) {
            ctx.save();
            ctx.translate(dx + (flipH ? this.tileSize : 0), dy + (flipV ? this.tileSize : 0));
            ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
            ctx.drawImage(
              this.tilesetImage,
              sx, sy, this.tileSize, this.tileSize,
              0, 0, this.tileSize, this.tileSize
            );
            ctx.restore();
          } else {
            ctx.drawImage(
              this.tilesetImage,
              sx, sy, this.tileSize, this.tileSize,
              dx, dy, this.tileSize, this.tileSize
            );
          }
        }
      }
    }
  }
}
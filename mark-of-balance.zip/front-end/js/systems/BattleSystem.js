const BATTLE_ENEMY_ASSETS = {
  morto_vivo: {
    baseSrc: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  morto_vivo_corrompido: {
    baseSrc: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  hospedeiro_cristalino: {
    baseSrc: './assets/hospedeiro cristalino.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/hospedeiro cristalino atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/hopedeiro cristalino atk pesado', count: 6 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  monge_corrompido: {
    baseSrc: './assets/monge corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/monge corrompido atk basico', count: 6 },
      ATAQUE_PESADO: { prefix: './assets/monge corrompido atk pesado', count: 6 },
      ATAQUE_ESPECIAL: { prefix: './assets/monge corrompido atk especial', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  boss_golem_de_pedra: {
    baseSrc: './assets/boss golem de pedra.png',
    attacks: {
      ATAQUE_PESADO: { prefix: './assets/boss golem de pedra artk pesado', count: 5 },
      ATAQUE_ESPECIAL: { prefix: './assets/boss golem de pedra artk especial', count: 5 },
    },
    filter: 'saturate(1.42) contrast(1.2) brightness(1.1)',
  },
  sentinela_gelo: {
    baseSrc: './assets/sentinela de gelo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/sentinela de gelo corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/sentinela de gelo corrompido atk pesado', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  sentinela_de_gelo_corrompido: {
    baseSrc: './assets/sentinela de gelo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/sentinela de gelo corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/sentinela de gelo corrompido atk pesado', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  lobo_geada: {
    baseSrc: './assets/lobo da geada corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/lobo da geada corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/lobo da geada corrompido atk pesado', count: 6 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  lobo_da_geada_corrompido: {
    baseSrc: './assets/lobo da geada corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/lobo da geada corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/lobo da geada corrompido atk pesado', count: 6 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  esqueleto_congelado: {
    baseSrc: './assets/esqueleto congelado corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/esqueleto congelado corrompido atk basico', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
  corrompido: {
    baseSrc: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    filter: 'saturate(1.38) contrast(1.18) brightness(1.1)',
  },
};

const battleSpriteCache = new Map();

function loadBattleImg(src) {
  const img = new Image();
  img.loadedOk = false;
  img.failed = false;
  img.onload = () => {
    img.loadedOk = true;
    img.failed = false;
  };
  img.onerror = () => {
    img.loadedOk = false;
    img.failed = true;
  };
  img.src = src;
  return img;
}

function resolveEnemyKey(enemy) {
  const rawName = (enemy?.nome || '').toLowerCase();
  let key = enemy?.tipoKey || 'morto_vivo_corrompido';
  if (!BATTLE_ENEMY_ASSETS[key]) {
    if (rawName.includes('golem') || rawName.includes('boss')) key = 'boss_golem_de_pedra';
    else if (rawName.includes('monge')) key = 'monge_corrompido';
    else if (rawName.includes('hospedeiro')) key = 'hospedeiro_cristalino';
    else if (rawName.includes('sentinela')) key = 'sentinela_gelo';
    else if (rawName.includes('lobo')) key = 'lobo_geada';
    else if (rawName.includes('esqueleto')) key = 'esqueleto_congelado';
    else if (rawName.includes('morto')) key = 'morto_vivo_corrompido';
  }
  return BATTLE_ENEMY_ASSETS[key] ? key : 'morto_vivo_corrompido';
}

function getBattleEnemySprites(enemy) {
  const key = resolveEnemyKey(enemy);
  const cfg = BATTLE_ENEMY_ASSETS[key];

  if (!battleSpriteCache.has(key)) {
    const baseImg = loadBattleImg(cfg.baseSrc);
    const attackFramesByKey = {};

    if (cfg.attacks) {
      for (const [atkKey, atkCfg] of Object.entries(cfg.attacks)) {
        const frames = [];
        if (atkCfg.prefix && atkCfg.count > 0) {
          for (let i = 1; i <= atkCfg.count; i++) {
            frames.push(loadBattleImg(`${atkCfg.prefix}${i}.png`));
          }
        }
        attackFramesByKey[atkKey] = frames;
      }
    }

    const attackFrames =
      attackFramesByKey.ATAQUE_BASICO ||
      attackFramesByKey.ATAQUE_PESADO ||
      attackFramesByKey.ATAQUE_ESPECIAL ||
      [];
    battleSpriteCache.set(key, { baseImg, attackFrames, attackFramesByKey, cfg });
  }
  return battleSpriteCache.get(key);
}

const PLAYER_HOME = { x: 180, y: 185 };
const PLAYER_STRIKE = { x: 325, y: 112 };
const ENEMY_HOME = { x: 392, y: 66 };
const ENEMY_STRIKE = { x: 235, y: 148 };

export class BattleSystem {
  constructor(apiClient = null) {
    this.apiClient = apiClient;
    this.backgroundImage = null;
    this.active = false;
    this.onlineMode = false;
    this.enemy = null;

    this.menu = 'PRINCIPAL';
    this.turno = 'JOGADOR';
    this.selectedIndex = 0;
    this.logs = [];
    this.turnTimer = 0;
    this.aguardandoServidor = false;
    this.animClock = 0;

    this.lunge = {
      phase: 'IDLE',
      actor: null,
      progress: 0,
      duration: 0.24,
      strikeTimer: 0,
      attackKey: null,
      onComplete: null,
    };
    this.playerOffset = { x: 0, y: 0 };
    this.enemyOffset = { x: 0, y: 0 };

    this.menuPrincipalOpcoes = [
      { id: 'ABRIR_ATAQUES', nome: 'Atacar' },
      { id: 'ABRIR_MOCHILA', nome: 'Mochila' },
      { id: 'FUGIR', nome: 'Fugir' },
    ];

    this.ataquesDisponiveis = [
      { id: 'golpe', categoria: 'FISICO', nome: 'Golpe Físico', estaminaAtual: 10, estaminaMaxima: 10 },
      { id: 'bola_de_fogo', categoria: 'MAGICO', nome: 'Bola de Fogo', estaminaAtual: 6, estaminaMaxima: 6 },
      { id: 'foco', categoria: 'BUFF', nome: 'Foco', estaminaAtual: 4, estaminaMaxima: 4 },
    ];

    this.itensDisponiveis = [
      { id: 'pocao_vida', nome: 'Poção de Vida', quantidade: 2 },
    ];
  }

  triggerEnemyTurnAnimation(attackKey = null) {
    if (!this.enemy) return;
    if (typeof this.enemy.triggerAttack === 'function') {
      this.enemy.triggerAttack(attackKey);
    } else if (typeof this.enemy.triggerBasicAttack === 'function') {
      this.enemy.triggerBasicAttack();
    }
  }

  startLungeSequence(actor, onComplete = null, attackKey = null) {
    this.lunge.phase = 'ADVANCING';
    this.lunge.actor = actor;
    this.lunge.progress = 0;
    this.lunge.duration = 0.24;
    this.lunge.strikeTimer = actor === 'ENEMY' ? 0.55 : 0.35;
    this.lunge.attackKey = attackKey;
    this.lunge.onComplete = onComplete;
  }

  resetLungeVisuals() {
    this.lunge.phase = 'IDLE';
    this.lunge.actor = null;
    this.lunge.progress = 0;
    this.lunge.attackKey = null;
    this.lunge.onComplete = null;
    this.playerOffset.x = 0;
    this.playerOffset.y = 0;
    this.enemyOffset.x = 0;
    this.enemyOffset.y = 0;
  }

  updateLungeSequence(deltaTime) {
    if (this.lunge.phase === 'IDLE') return;

    const isPlayer = this.lunge.actor === 'PLAYER';
    const home = isPlayer ? PLAYER_HOME : ENEMY_HOME;
    const strike = isPlayer ? PLAYER_STRIKE : ENEMY_STRIKE;
    const targetOffset = isPlayer ? this.playerOffset : this.enemyOffset;

    if (this.lunge.phase === 'ADVANCING') {
      this.lunge.progress = Math.min(1, this.lunge.progress + deltaTime / this.lunge.duration);
      const t = this.lunge.progress;
      targetOffset.x = (strike.x - home.x) * t;
      targetOffset.y = (strike.y - home.y) * t;

      if (this.lunge.progress >= 1) {
        this.lunge.phase = 'STRIKING';
        this.lunge.progress = 0;
        if (!isPlayer) {
          this.triggerEnemyTurnAnimation(this.lunge.attackKey);
        }
      }
    } else if (this.lunge.phase === 'STRIKING') {
      this.lunge.strikeTimer -= deltaTime;
      if (this.lunge.strikeTimer <= 0) {
        this.lunge.phase = 'RETURNING';
        this.lunge.progress = 0;
      }
    } else if (this.lunge.phase === 'RETURNING') {
      this.lunge.progress = Math.min(1, this.lunge.progress + deltaTime / this.lunge.duration);
      const t = 1 - this.lunge.progress;
      targetOffset.x = (strike.x - home.x) * t;
      targetOffset.y = (strike.y - home.y) * t;

      if (this.lunge.progress >= 1) {
        targetOffset.x = 0;
        targetOffset.y = 0;
        const cb = this.lunge.onComplete;
        this.lunge.phase = 'IDLE';
        this.lunge.actor = null;
        this.lunge.attackKey = null;
        this.lunge.onComplete = null;
        if (typeof cb === 'function') cb();
      }
    }
  }

  async startBattle(player, enemy, respostaServidor = null) {
    this.active = true;
    this.enemy = enemy;
    this.resetLungeVisuals();

    if (this.enemy) {
      this.enemy.isAttacking = false;
      this.enemy.attackIndex = 0;
      this.enemy.attackTimer = 0;
      this.enemy.currentAttackKey = this.enemy.attacks?.[0] || 'ATAQUE_BASICO';
      this.enemy.turnCounter = 0;
    }
    this.menu = 'PRINCIPAL';
    this.turno = 'JOGADOR';
    this.selectedIndex = 0;
    this.aguardandoServidor = false;
    this.animClock = 0;
    this.onlineMode = Boolean(this.apiClient && this.apiClient.conectado && respostaServidor);

    for (const atk of this.ataquesDisponiveis) {
      atk.estaminaAtual = atk.estaminaMaxima;
    }

    if (this.onlineMode && respostaServidor) {
      this.aplicarRespostaServidor(player, respostaServidor);
      await this.carregarOpcoesDoServidor();
    } else {
      this.logs = [`Um ${enemy.nome} (Nv.${enemy.nivel}) apareceu!`];
    }
  }

  async carregarOpcoesDoServidor() {
    if (!this.onlineMode) return;

    const [fisicos, magicos, buffs, itens] = await Promise.all([
      this.apiClient.opcoesAtaque('FISICO'),
      this.apiClient.opcoesAtaque('MAGICO'),
      this.apiClient.opcoesAtaque('BUFF'),
      this.apiClient.opcoesItens(),
    ]);

    const listaAtaques = [];
    if (fisicos?.ok && Array.isArray(fisicos.opcoes)) {
      fisicos.opcoes.forEach((o) => listaAtaques.push({ id: o.id, categoria: 'FISICO', nome: o.nome }));
    }
    if (magicos?.ok && Array.isArray(magicos.opcoes)) {
      magicos.opcoes.forEach((o) => listaAtaques.push({ id: o.id, categoria: 'MAGICO', nome: o.nome }));
    }
    if (buffs?.ok && Array.isArray(buffs.opcoes)) {
      buffs.opcoes.forEach((o) => listaAtaques.push({ id: o.id, categoria: 'BUFF', nome: o.nome }));
    }
    if (listaAtaques.length > 0) {
      this.ataquesDisponiveis = listaAtaques;
    }

    if (itens?.ok && Array.isArray(itens.opcoes)) {
      this.itensDisponiveis = itens.opcoes.map((o) => ({ id: o.id, nome: o.nome, quantidade: 1 }));
    }
  }

  addLog(msg) {
    if (!msg) return;
    this.logs.push(msg);
    if (this.logs.length > 4) this.logs.shift();
  }

  aplicarRespostaServidor(player, resp) {
    if (!resp) return;

    if (Array.isArray(resp.eventos) && resp.eventos.length > 0) {
      resp.eventos.forEach((ev) => this.addLog(ev.texto));
    } else if (resp.mensagem) {
      this.addLog(resp.mensagem);
    }

    if (resp.inimigo && this.enemy) {
      this.enemy.nome = resp.inimigo.nome || this.enemy.nome;
      this.enemy.nivel = resp.inimigo.nivel || this.enemy.nivel;
      if (typeof resp.inimigo.vida === 'number') {
        this.enemy.vida = resp.inimigo.vida;
      }
    }

    if (resp.heroi && player && typeof resp.heroi.vida === 'number') {
      player.vida = resp.heroi.vida;
    }

    if (resp.menu) this.menu = resp.menu;
    if (resp.turno) this.turno = resp.turno;

    if (resp.resultadoBatalha === 'VITORIA') {
      if (this.enemy) this.enemy.state = 'DEAD';
      this.turno = 'VITORIA';
      this.addLog('Vitória! Pressione [ENTER]');
    } else if (resp.resultadoBatalha === 'DERROTA') {
      player.state = 'DEAD';
      this.turno = 'DERROTA';
      this.addLog('Você foi derrotado... [ENTER]');
    } else if (resp.resultadoBatalha === 'FUGA') {
      this.turno = 'FUGA';
      this.addLog('Você fugiu! [ENTER]');
    } else if (this.turno === 'INIMIGO') {
      const ataqueServidor = resp.ataqueInimigo || resp.golpeInimigo || null;
      this.turno = 'ANIMANDO';
      this.startLungeSequence('ENEMY', () => {
        this.turno = 'INIMIGO';
        this.turnTimer = 0.25;
      }, ataqueServidor);
    }
  }

  getOpcoesAtuais() {
    if (this.menu === 'ATAQUES') {
      return [...this.ataquesDisponiveis, { id: 'VOLTAR', nome: 'Voltar' }];
    }
    if (this.menu === 'MOCHILA') {
      return [...this.itensDisponiveis, { id: 'VOLTAR', nome: 'Voltar' }];
    }
    return this.menuPrincipalOpcoes;
  }

  async confirmarSelecao(player) {
    if (this.aguardandoServidor || this.turno !== 'JOGADOR' || this.lunge.phase !== 'IDLE') return;

    const opcoes = this.getOpcoesAtuais();
    const escolha = opcoes[this.selectedIndex];
    if (!escolha) return;

    if (this.onlineMode) {
      this.aguardandoServidor = true;
      let resp = null;

      if (this.menu === 'PRINCIPAL') {
        resp = await this.apiClient.comandoBatalha(escolha.id);
      } else if (this.menu === 'ATAQUES') {
        if (escolha.id === 'VOLTAR') {
          resp = await this.apiClient.comandoBatalha('VOLTAR');
        } else {
          resp = await this.apiClient.comandoBatalha('ATACAR', {
            categoria: escolha.categoria,
            id: escolha.id,
          });
        }
      } else if (this.menu === 'MOCHILA') {
        if (escolha.id === 'VOLTAR') {
          resp = await this.apiClient.comandoBatalha('VOLTAR');
        } else {
          resp = await this.apiClient.comandoBatalha('USAR_ITEM', { id: escolha.id });
          await this.carregarOpcoesDoServidor();
        }
      }

      this.selectedIndex = 0;
      const foiAtaque = this.menu === 'ATAQUES' && escolha.id !== 'VOLTAR';
      this.aguardandoServidor = false;

      if (foiAtaque) {
        this.turno = 'ANIMANDO';
        this.startLungeSequence('PLAYER', () => {
          this.aplicarRespostaServidor(player, resp);
        });
      } else {
        this.aplicarRespostaServidor(player, resp);
      }
      return;
    }

    if (this.menu === 'PRINCIPAL') {
      if (escolha.id === 'ABRIR_ATAQUES') {
        this.menu = 'ATAQUES';
        this.selectedIndex = 0;
      } else if (escolha.id === 'ABRIR_MOCHILA') {
        this.menu = 'MOCHILA';
        this.selectedIndex = 0;
      } else if (escolha.id === 'FUGIR') {
        this.turno = 'FUGA';
        this.addLog('Você fugiu! [ENTER]');
      }
      return;
    }

    if (this.menu === 'ATAQUES') {
      if (escolha.id === 'VOLTAR') {
        this.menu = 'PRINCIPAL';
        this.selectedIndex = 0;
        return;
      }
      this.executarAtaqueSemDanoLocal(escolha);
      return;
    }

    if (this.menu === 'MOCHILA') {
      if (escolha.id === 'VOLTAR') {
        this.menu = 'PRINCIPAL';
        this.selectedIndex = 0;
        return;
      }
      if (escolha.quantidade > 0) {
        escolha.quantidade--;
        this.addLog(`${escolha.nome} usado.`);
        this.menu = 'PRINCIPAL';
        this.selectedIndex = 0;
        this.turno = 'ANIMANDO';
        this.startLungeSequence('ENEMY', () => {
          this.turno = 'INIMIGO';
          this.turnTimer = 0.25;
        });
      }
    }
  }

  executarAtaqueSemDanoLocal(ataque) {
    if (ataque.estaminaAtual <= 0) {
      this.addLog(`${ataque.nome} sem estamina!`);
      return;
    }
    ataque.estaminaAtual--;
    this.menu = 'PRINCIPAL';
    this.selectedIndex = 0;
    this.turno = 'ANIMANDO';
    this.addLog(`${ataque.nome} executado.`);

    this.startLungeSequence('PLAYER', () => {
      this.turno = 'ANIMANDO';
      this.startLungeSequence('ENEMY', () => {
        this.turno = 'INIMIGO';
        this.turnTimer = 0.2;
      });
    });
  }

  async executarTurnoInimigo(player) {
    if (this.onlineMode) {
      if (this.aguardandoServidor) return;
      this.aguardandoServidor = true;
      const resp = await this.apiClient.comandoBatalha('TURNO_INIMIGO');
      this.aguardandoServidor = false;
      this.aplicarRespostaServidor(player, resp);
      return;
    }

    const ataqueAtual = this.enemy?.currentAttackKey || 'ATAQUE_BASICO';
    if (ataqueAtual === 'ATAQUE_ESPECIAL') {
      this.addLog(`${this.enemy.nome} usou Ataque Especial.`);
    } else if (ataqueAtual === 'ATAQUE_PESADO') {
      this.addLog(`${this.enemy.nome} usou Ataque Pesado.`);
    } else {
      this.addLog(`${this.enemy.nome} atacou.`);
    }
    this.turno = 'JOGADOR';
  }

  update(deltaTime, player, input) {
    if (!this.active) return null;

    this.animClock += deltaTime;
    this.updateLungeSequence(deltaTime);

    if (this.enemy && typeof this.enemy.updateAttackAnimation === 'function') {
      this.enemy.updateAttackAnimation(deltaTime);
    }

    if (this.lunge.phase !== 'IDLE') {
      return null;
    }

    if (this.turno === 'JOGADOR') {
      const opcoes = this.getOpcoesAtuais();
      if (input.consumeKey('w') || input.consumeKey('arrowup')) {
        this.selectedIndex = (this.selectedIndex - 1 + opcoes.length) % opcoes.length;
      }
      if (input.consumeKey('s') || input.consumeKey('arrowdown')) {
        this.selectedIndex = (this.selectedIndex + 1) % opcoes.length;
      }
      if ((input.consumeKey('escape') || input.consumeKey('x')) && this.menu !== 'PRINCIPAL') {
        if (this.onlineMode) {
          this.apiClient.comandoBatalha('VOLTAR').then((r) => this.aplicarRespostaServidor(player, r));
        } else {
          this.menu = 'PRINCIPAL';
        }
        this.selectedIndex = 0;
      }
      if (input.consumeKey('enter') || input.consumeKey('j')) {
        this.confirmarSelecao(player);
      }
    } else if (this.turno === 'INIMIGO') {
      this.turnTimer -= deltaTime;
      if (this.turnTimer <= 0) {
        this.turnTimer = 999;
        this.executarTurnoInimigo(player);
      }
    } else if (this.turno === 'VITORIA' || this.turno === 'FUGA') {
      if (input.consumeKey('enter') || input.consumeKey('j')) {
        const resultadoFinal = this.turno;
        this.active = false;
        this.resetLungeVisuals();
        return resultadoFinal;
      }
    } else if (this.turno === 'DERROTA') {
      if (input.consumeKey('enter') || input.consumeKey('j')) {
        this.active = false;
        this.resetLungeVisuals();
        return 'DERROTA';
      }
    }

    return null;
  }

  drawBar(ctx, x, y, w, h, ratio, fillColor, bgColor = null) {
    const safeRatio = Math.max(0, Math.min(1, ratio));
    if (bgColor) {
      ctx.fillStyle = bgColor;
      ctx.fillRect(x, y, w, h);
    }

    const fillW = Math.round(w * safeRatio);
    if (fillW > 0) {
      ctx.fillStyle = fillColor;
      ctx.fillRect(x, y, fillW, h);
    }
  }

  renderEnemyInBattle(ctx, drawX, drawY, drawW, drawH) {
    const { baseImg, attackFrames, attackFramesByKey, cfg } = getBattleEnemySprites(this.enemy);
    const filterCss = cfg?.filter || 'saturate(1.38) contrast(1.18) brightness(1.1)';
    const breatheOffset = Math.sin(this.animClock * 5) * 2;
    const finalY = Math.round(drawY + breatheOffset);

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.filter = filterCss;

    if (
      this.enemy &&
      this.enemy.isAttacking &&
      typeof this.enemy.renderAttackFrame === 'function'
    ) {
      const framesAtuais = this.enemy.getFramesForAttack?.(this.enemy.currentAttackKey) || [];
      const temValido = framesAtuais.some((f) => f.loadedOk && !f.failed);
      if (temValido && this.enemy.renderAttackFrame(ctx, drawX, finalY, drawW, drawH)) {
        ctx.restore();
        return;
      }
    }

    if (this.enemy && this.enemy.isAttacking) {
      const atkKey = this.enemy.currentAttackKey || 'ATAQUE_BASICO';
      const lista = attackFramesByKey?.[atkKey]?.length ? attackFramesByKey[atkKey] : attackFrames;
      const validos = lista.filter((f) => f.loadedOk && !f.failed);
      if (validos.length > 0) {
        const frame = validos[(this.enemy.attackIndex || 0) % validos.length];
        ctx.drawImage(frame, 0, 0, frame.width, frame.height, drawX, finalY, drawW, drawH);
        ctx.restore();
        return;
      }
    }

    if (baseImg && baseImg.loadedOk && !baseImg.failed && baseImg.width > 0 && baseImg.height > 0) {
      ctx.drawImage(baseImg, 0, 0, baseImg.width, baseImg.height, drawX, finalY, drawW, drawH);
      ctx.restore();
      return;
    }

    ctx.restore();
    ctx.fillStyle = '#2ec4b6';
    ctx.fillRect(drawX + 4, finalY + 16, drawW - 8, drawH - 20);
    ctx.fillStyle = '#14141f';
    ctx.fillRect(drawX + 12, finalY + 23, 4, 4);
    ctx.fillRect(drawX + 26, finalY + 23, 4, 4);
  }

  render(ctx, canvas, player) {
    if (!this.active || !this.enemy) return;

    if (this.backgroundImage && this.backgroundImage.complete && this.backgroundImage.naturalWidth > 0) {
      ctx.drawImage(this.backgroundImage, 0, 0, canvas.width, canvas.height);
    } else {
      ctx.fillStyle = '#14141f';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    const enemyMaxHp = this.enemy.stats ? this.enemy.stats.getInt('VIDA_MAXIMA') : 40;
    const enemyHpRatio = enemyMaxHp > 0 ? this.enemy.vida / enemyMaxHp : 0;

    ctx.font = 'bold 13px monospace';
    ctx.fillStyle = '#5c4b4b';
    ctx.fillText(this.enemy.nome.toUpperCase(), 30, 30);

    const enemyNameW = ctx.measureText(this.enemy.nome.toUpperCase()).width;
    ctx.fillStyle = '#d64545';
    ctx.fillText(`L${this.enemy.nivel}`, 30 + enemyNameW + 10, 30);

    this.drawBar(ctx, 76, 39, 175, 5, enemyHpRatio, '#70c936', '#5e3c3c');

    const enemyDrawX = Math.round(ENEMY_HOME.x + this.enemyOffset.x);
    const enemyDrawY = Math.round(ENEMY_HOME.y + this.enemyOffset.y);
    this.renderEnemyInBattle(ctx, enemyDrawX, enemyDrawY, 108, 108);

    const playerMaxHp = player.stats ? player.stats.getInt('VIDA_MAXIMA') : 100;
    const playerMaxMp = player.stats ? player.stats.getInt('ENERGIA_MAXIMA') : 50;
    const playerHpRatio = playerMaxHp > 0 ? player.vida / playerMaxHp : 0;
    const playerMpRatio = playerMaxMp > 0 ? player.energia / playerMaxMp : 0;
    const nivelPlayer = player.progressao ? player.progressao.nivel : 1;

    const playerDrawX = Math.round(PLAYER_HOME.x + this.playerOffset.x);
    const playerDrawY = Math.round(PLAYER_HOME.y + this.playerOffset.y);

    const activePlayerImg =
      typeof player.getActiveFrameImage === 'function' ? player.getActiveFrameImage() : player.sprite;
    if (activePlayerImg && activePlayerImg.complete && activePlayerImg.naturalWidth > 0) {
      ctx.drawImage(activePlayerImg, playerDrawX, playerDrawY, 36, 54);
    } else {
      ctx.fillStyle = '#4ecdc4';
      ctx.fillRect(playerDrawX, playerDrawY + 10, 36, 44);
    }

    const nomeHeroi = (player.nome || 'Arthur').toUpperCase();
    ctx.font = 'bold 13px monospace';
    ctx.fillStyle = '#5c4b4b';
    ctx.fillText(nomeHeroi, 400, 214);

    const heroNameW = ctx.measureText(nomeHeroi).width;
    ctx.fillStyle = '#d64545';
    ctx.fillText(`L${nivelPlayer}`, 400 + heroNameW + 10, 214);

    this.drawBar(ctx, 446, 221, 175, 3, playerMpRatio, '#4ea8de', '#23384d');
    this.drawBar(ctx, 446, 229, 175, 5, playerHpRatio, '#70c936', '#5e3c3c');

    ctx.font = 'bold 11px monospace';
    ctx.fillStyle = '#5c4b4b';
    ctx.textAlign = 'right';
    ctx.fillText(`${player.vida}/${playerMaxHp}`, 622, 247);
    ctx.textAlign = 'left';

    ctx.fillStyle = '#5c4b4b';
    ctx.font = 'bold 13px monospace';
    this.logs.slice(-3).forEach((line, i) => {
      ctx.fillText(line, 24, 302 + i * 18);
    });

    const opcoes = this.getOpcoesAtuais();
    ctx.font = 'bold 13px monospace';
    opcoes.forEach((op, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const ax = 392 + col * 126;
      const ay = 304 + row * 28;
      const selected = i === this.selectedIndex && this.turno === 'JOGADOR';

      if (selected) {
        ctx.fillStyle = '#6b2d2d';
        ctx.beginPath();
        ctx.moveTo(ax - 14, ay - 9);
        ctx.lineTo(ax - 5, ay - 4);
        ctx.lineTo(ax - 14, ay + 1);
        ctx.closePath();
        ctx.fill();
      }

      ctx.fillStyle = selected ? '#3b1d6e' : '#5c4b4b';
      const extra = op.estaminaMaxima != null ? ` (${op.estaminaAtual})` : '';
      ctx.fillText(`${op.nome}${extra}`, ax, ay);
    });
  }
}
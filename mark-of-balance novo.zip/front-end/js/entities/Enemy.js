import { StatSheet } from '../systems/ProgressionSystem.js';

const ENEMY_SPRITE_CONFIG = {
  morto_vivo: {
    src: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#6c584c',
  },
  morto_vivo_corrompido: {
    src: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#6c584c',
  },
  hospedeiro_cristalino: {
    src: './assets/hospedeiro cristalino.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/hospedeiro cristalino atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/hopedeiro cristalino atk pesado', count: 6 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#b5179e',
  },
  monge_corrompido: {
    src: './assets/monge corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/monge corrompido atk basico', count: 6 },
      ATAQUE_PESADO: { prefix: './assets/monge corrompido atk pesado', count: 6 },
      ATAQUE_ESPECIAL: { prefix: './assets/monge corrompido atk especial', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#7209b7',
  },
  boss_golem_de_pedra: {
    src: './assets/boss golem de pedra.png',
    attacks: {
      ATAQUE_PESADO: { prefix: './assets/boss golem de pedra artk pesado', count: 5 },
      ATAQUE_ESPECIAL: { prefix: './assets/boss golem de pedra artk especial', count: 5 },
    },
    singleSprite: true,
    renderWidth: 44,
    renderHeight: 44,
    offsetY: -26,
    filter: 'saturate(1.38) contrast(1.18) brightness(1.08)',
    fallbackColor: '#495057',
  },
  sentinela_gelo: {
    src: './assets/sentinela de gelo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/sentinela de gelo corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/sentinela de gelo corrompido atk pesado', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#4cc9f0',
  },
  sentinela_de_gelo_corrompido: {
    src: './assets/sentinela de gelo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/sentinela de gelo corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/sentinela de gelo corrompido atk pesado', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#4cc9f0',
  },
  lobo_geada: {
    src: './assets/lobo da geada corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/lobo da geada corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/lobo da geada corrompido atk pesado', count: 6 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#4895ef',
  },
  lobo_da_geada_corrompido: {
    src: './assets/lobo da geada corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/lobo da geada corrompido atk basico', count: 5 },
      ATAQUE_PESADO: { prefix: './assets/lobo da geada corrompido atk pesado', count: 6 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#4895ef',
  },
  esqueleto_congelado: {
    src: './assets/esqueleto congelado corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/esqueleto congelado corrompido atk basico', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#90e0ef',
  },
  corrompido: {
    src: './assets/morto vivo corrompido.png',
    attacks: {
      ATAQUE_BASICO: { prefix: './assets/morto vivo corrompido', count: 5 },
    },
    singleSprite: true,
    renderWidth: 38,
    renderHeight: 38,
    offsetY: -20,
    filter: 'saturate(1.35) contrast(1.15) brightness(1.08)',
    fallbackColor: '#e63946',
  },
};

const spriteCache = new Map();

function createTrackableImage(src) {
  const img = new Image();
  img.loadedOk = false;
  img.failed = false;
  img.onload = () => {
    img.loadedOk = true;
    img.failed = false;
  };
  img.onerror = () => {
    img.loadedOk = false;
    img.failed = true;
  };
  img.src = src;
  return img;
}

function resolverTipoEnemy(tipoKey) {
  if (ENEMY_SPRITE_CONFIG[tipoKey]) return tipoKey;
  const k = (tipoKey || '').toLowerCase();
  if (k.includes('golem') || k.includes('boss')) return 'boss_golem_de_pedra';
  if (k.includes('monge')) return 'monge_corrompido';
  if (k.includes('hospedeiro')) return 'hospedeiro_cristalino';
  if (k.includes('sentinela')) return 'sentinela_gelo';
  if (k.includes('lobo')) return 'lobo_geada';
  if (k.includes('esqueleto')) return 'esqueleto_congelado';
  return 'morto_vivo_corrompido';
}

function getEnemyAssets(tipoKey) {
  const resolvedKey = resolverTipoEnemy(tipoKey);
  const cfg = ENEMY_SPRITE_CONFIG[resolvedKey];

  if (!spriteCache.has(resolvedKey)) {
    const baseImg = createTrackableImage(cfg.src);
    const attackFramesByKey = {};

    if (cfg.attacks) {
      for (const [atkKey, atkCfg] of Object.entries(cfg.attacks)) {
        const frames = [];
        if (atkCfg.prefix && atkCfg.count > 0) {
          for (let i = 1; i <= atkCfg.count; i++) {
            frames.push(createTrackableImage(`${atkCfg.prefix}${i}.png`));
          }
        }
        attackFramesByKey[atkKey] = frames;
      }
    }

    const attackFrames =
      attackFramesByKey.ATAQUE_BASICO ||
      attackFramesByKey.ATAQUE_PESADO ||
      attackFramesByKey.ATAQUE_ESPECIAL ||
      [];
    spriteCache.set(resolvedKey, { baseImg, attackFrames, attackFramesByKey, cfg });
  }

  return spriteCache.get(resolvedKey);
}

export class Enemy {
  constructor(
    x,
    y,
    nome = 'Morto-Vivo Corrompido',
    nivel = 1,
    tipoKey = 'morto_vivo_corrompido'
  ) {
    this.x = x;
    this.y = y;
    this.width = 16;
    this.height = 16;
    this.nome = nome;
    this.nivel = nivel;
    this.tipoKey = resolverTipoEnemy(tipoKey || nome);

    const lowerNome = (nome || '').toLowerCase();
    const ehHospedeiro =
      this.tipoKey === 'hospedeiro_cristalino' || lowerNome.includes('hospedeiro');
    const ehMonge =
      this.tipoKey === 'monge_corrompido' || lowerNome.includes('monge');
    const ehGolemBoss =
      this.tipoKey === 'boss_golem_de_pedra' ||
      lowerNome.includes('golem') ||
      lowerNome.includes('boss');
    const ehSentinelaOuLobo =
      this.tipoKey === 'sentinela_gelo' ||
      this.tipoKey === 'lobo_geada' ||
      lowerNome.includes('sentinela') ||
      lowerNome.includes('lobo');

    if (ehMonge) {
      this.attacks = ['ATAQUE_BASICO', 'ATAQUE_PESADO', 'ATAQUE_ESPECIAL'];
      this.currentAttackKey = 'ATAQUE_BASICO';
    } else if (ehGolemBoss) {
      this.attacks = ['ATAQUE_PESADO', 'ATAQUE_ESPECIAL'];
      this.currentAttackKey = 'ATAQUE_PESADO';
    } else if (ehHospedeiro || ehSentinelaOuLobo) {
      this.attacks = ['ATAQUE_BASICO', 'ATAQUE_PESADO'];
      this.currentAttackKey = 'ATAQUE_BASICO';
    } else {
      this.attacks = ['ATAQUE_BASICO'];
      this.currentAttackKey = 'ATAQUE_BASICO';
    }

    this.turnCounter = 0;
    this.attackIndex = 0;
    this.attackTimer = 0;
    this.attackFrameDuration = 0.1;
    this.isAttacking = false;

    this.hitbox = { offsetX: 2, offsetY: 6, width: 12, height: 10 };

    const n = nivel - 1;
    this.stats = new StatSheet({
      VIDA_MAXIMA: ehGolemBoss
        ? 95 + 26 * n
        : ehMonge || ehHospedeiro
          ? 55 + 18 * n
          : 40 + 14 * n,
      ENERGIA_MAXIMA: 20 + 2 * n,
      FORCA: ehGolemBoss
        ? 11 + 2.8 * n
        : ehMonge || ehHospedeiro
          ? 8 + 2.2 * n
          : 6 + 1.8 * n,
      DEFESA: ehGolemBoss
        ? 5 + 1.4 * n
        : ehMonge || ehHospedeiro
          ? 3 + 1 * n
          : 2 + 0.8 * n,
      VELOCIDADE: 8 + 0.3 * n,
    });

    this.vida = this.stats.getInt('VIDA_MAXIMA');
    this.xpBase = ehGolemBoss
      ? 40 + 12 * nivel
      : ehMonge || ehHospedeiro
        ? 22 + 8 * nivel
        : 15 + 6 * nivel;
    this.xpConcedido = false;

    this.speed = 36;
    this.aggroRange = 95;
    this.state = 'IDLE';
    this.facing = 'right';
    this.animTimer = 0;
    this.idleTimer = 0;
    this.frameIndex = 0;
  }

  getHitboxAt(x, y) {
    return {
      x: x + this.hitbox.offsetX,
      y: y + this.hitbox.offsetY,
      width: this.hitbox.width,
      height: this.hitbox.height,
    };
  }

  canOccupy(x, y, tileMap) {
    const hb = this.getHitboxAt(x, y);
    if (
      hb.x < 0 ||
      hb.y < 0 ||
      hb.x + hb.width > tileMap.pixelWidth ||
      hb.y + hb.height > tileMap.pixelHeight
    ) {
      return false;
    }
    if (tileMap.checkCollision(hb)) return false;
    return true;
  }

  xpPara(nivelDoJogador) {
    let fator = 1 + 0.1 * (this.nivel - nivelDoJogador);
    fator = Math.max(0.1, Math.min(1.5, fator));
    return Math.max(1, Math.round(this.xpBase * fator));
  }

  escolherAtaque() {
    if (!Array.isArray(this.attacks) || this.attacks.length === 0) {
      return 'ATAQUE_BASICO';
    }
    const escolhido = this.attacks[this.turnCounter % this.attacks.length];
    this.turnCounter++;
    return escolhido;
  }

  getFramesForAttack(attackKey = null) {
    const { attackFramesByKey, attackFrames } = getEnemyAssets(this.tipoKey);
    const key = attackKey || this.currentAttackKey || 'ATAQUE_BASICO';
    const frames = attackFramesByKey?.[key];
    if (frames && frames.length > 0) return frames;
    return attackFrames || [];
  }

  triggerAttack(attackKey = null) {
    const escolhido = attackKey || this.escolherAtaque();
    this.currentAttackKey = escolhido;
    const frames = this.getFramesForAttack(escolhido);
    const validos = frames.filter((f) => f.loadedOk && !f.failed);
    if (!validos.length) return escolhido;
    this.isAttacking = true;
    this.attackIndex = 0;
    this.attackTimer = 0;
    return escolhido;
  }

  triggerBasicAttack() {
    return this.triggerAttack('ATAQUE_BASICO');
  }

  updateAttackAnimation(deltaTime) {
    if (!this.isAttacking) return;

    const frames = this.getFramesForAttack(this.currentAttackKey);
    const validos = frames.filter((f) => f.loadedOk && !f.failed);
    if (!validos.length) {
      this.isAttacking = false;
      return;
    }

    this.attackTimer += deltaTime;
    if (this.attackTimer >= this.attackFrameDuration) {
      this.attackTimer = 0;
      this.attackIndex++;
      if (this.attackIndex >= validos.length) {
        this.attackIndex = 0;
        this.isAttacking = false;
      }
    }
  }

  drawSingleSprite(ctx, img, drawX, drawY, renderW, renderH, flipX = false, filterCss = 'none') {
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.filter = filterCss;

    if (flipX) {
      ctx.translate(drawX + renderW, drawY);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, renderW, renderH);
    } else {
      ctx.drawImage(img, 0, 0, img.width, img.height, drawX, drawY, renderW, renderH);
    }

    ctx.restore();
  }

  renderAttackFrame(ctx, drawX, drawY, drawW = null, drawH = null) {
    const { cfg } = getEnemyAssets(this.tipoKey);
    const frames = this.getFramesForAttack(this.currentAttackKey);
    const validos = frames.filter((f) => f.loadedOk && !f.failed);
    if (!validos.length) return false;

    const frame = validos[this.attackIndex] || validos[0];
    if (!frame || !frame.loadedOk || frame.width <= 0 || frame.height <= 0) {
      return false;
    }

    const w = drawW ?? cfg.renderWidth ?? this.width;
    const h = drawH ?? cfg.renderHeight ?? this.height;
    const flipX = this.facing === 'left';
    const filterCss = cfg.filter || 'none';

    this.drawSingleSprite(ctx, frame, Math.round(drawX), Math.round(drawY), w, h, flipX, filterCss);
    return true;
  }

  update(deltaTime, player, tileMap) {
    if (this.state === 'DEAD') return;

    this.updateAttackAnimation(deltaTime);

    const dx = player.x - this.x;
    const dy = player.y - this.y;
    const dist = Math.hypot(dx, dy);

    let moved = false;

    if (dist <= this.aggroRange && dist > 2 && player.state !== 'DEAD') {
      this.state = 'CHASE';
      const moveX = (dx / dist) * this.speed;
      const moveY = (dy / dist) * this.speed;

      if (Math.abs(moveX) > 0.1) {
        this.facing = moveX >= 0 ? 'right' : 'left';
      }

      const nextX = this.x + moveX * deltaTime;
      if (this.canOccupy(nextX, this.y, tileMap)) {
        this.x = nextX;
        moved = true;
      }

      const nextY = this.y + moveY * deltaTime;
      if (this.canOccupy(this.x, nextY, tileMap)) {
        this.y = nextY;
        moved = true;
      }
    } else {
      this.state = 'IDLE';
    }

    if (moved) {
      this.animTimer += deltaTime;
      if (this.animTimer >= 0.16) {
        this.animTimer = 0;
        this.frameIndex = (this.frameIndex + 1) % 2;
      }
    } else {
      this.idleTimer += deltaTime;
      if (this.idleTimer >= 0.45) {
        this.idleTimer = 0;
        this.frameIndex = this.frameIndex === 0 ? 1 : 0;
      }
    }
  }

  render(ctx, camera) {
    if (this.state === 'DEAD') return;

    const { baseImg, cfg } = getEnemyAssets(this.tipoKey);
    const renderW = cfg.renderWidth || this.width;
    const renderH = cfg.renderHeight || this.height;
    const offsetX = Math.round((this.width - renderW) / 2);
    const offsetY = cfg.offsetY ?? 0;
    const filterCss = cfg.filter || 'none';

    const bob = this.frameIndex === 1 ? -1 : 0;

    const drawX = Math.round(this.x - camera.x) + offsetX;
    const drawY = Math.round(this.y - camera.y) + offsetY + bob;
    const flipX = this.facing === 'left';

    ctx.imageSmoothingEnabled = false;

    if (this.isAttacking && this.renderAttackFrame(ctx, drawX, drawY, renderW, renderH)) {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 6px monospace';
      ctx.fillText(`Nv.${this.nivel}`, Math.round(this.x - camera.x), Math.round(this.y - camera.y) - 6);
      return;
    }

    if (baseImg.loadedOk && !baseImg.failed && baseImg.width > 0 && baseImg.height > 0) {
      this.drawSingleSprite(ctx, baseImg, drawX, drawY, renderW, renderH, flipX, filterCss);
    } else {
      ctx.fillStyle = cfg.fallbackColor;
      ctx.fillRect(Math.round(this.x - camera.x) + 2, Math.round(this.y - camera.y) + 4, 12, 12);
    }

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 6px monospace';
    ctx.fillText(`Nv.${this.nivel}`, Math.round(this.x - camera.x), Math.round(this.y - camera.y) - 6);
  }
}